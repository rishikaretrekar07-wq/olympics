# Tableau Build Guide

## 1. Connect the data
1. Open Tableau Desktop or Tableau Public.
2. Connect to `data/olympic_results_1992_2022.csv` (or use `Global_Olympic_Analysis_Data.xlsx` and select `Results_Clean`).
3. Confirm `year` is a whole number/date-compatible numeric field and `place` is numeric.
4. Add `athlete_bios_clean.csv` only if you need athlete attributes. Relate/join on `athlete_id`; prefer a relationship to avoid unintentionally multiplying result rows.
5. Filter out null `year`, null `type`, and null `noc` only when appropriate for the specific chart. Document filters.

## 2. Create calculated fields
**Medal Record**
```
IF [medal] = "Gold" OR [medal] = "Silver" OR [medal] = "Bronze" THEN 1 ELSE 0 END
```

**Gold Record**
```
IF [medal] = "Gold" THEN 1 ELSE 0 END
```

**Silver Record**
```
IF [medal] = "Silver" THEN 1 ELSE 0 END
```

**Bronze Record**
```
IF [medal] = "Bronze" THEN 1 ELSE 0 END
```

**Medal Tier Sort**
```
CASE [medal]
WHEN "Gold" THEN 1
WHEN "Silver" THEN 2
WHEN "Bronze" THEN 3
ELSE 4
END
```

**Games Label**
```
STR([year]) + " " + [type]
```

**Medal Status**
```
IF ISNULL([medal]) THEN "No medal recorded" ELSE [medal] END
```

Use `SUM([Medal Record])` and label it **Athlete-medal records** to avoid implying official unique medal counts. For a unique-medal analysis, create a carefully validated event-level deduplication key using year, Games type, discipline, event, NOC, team, and medal; inspect edge cases before using it.

## 3. Build worksheets
1. **KPI – Athlete-medal records:** `SUM([Medal Record])` as a big number.
2. **Medal records by NOC:** Rows = `noc`; Columns = `SUM([Medal Record])`; sort descending; Top 10 filter.
3. **Medal composition:** `medal` on Color, `SUM([Medal Record])` on Columns, `noc` on Rows; filter to top NOCs.
4. **Trend over time:** Columns = `year` (continuous), Rows = `SUM([Medal Record])`, Color = `type`.
5. **Discipline ranking:** Rows = `discipline`, Columns = `SUM([Medal Record])`; sort descending; Top 15 filter.
6. **Participation trend:** use a separate worksheet based on `participation_by_year.csv`; chart `unique_athletes` by year and type.
7. **Country comparison:** use `country_medal_trends.csv`; year on Columns, `athlete_medal_records` on Rows, NOC on Color or as a filter.
8. **Medal distribution:** use `medals_by_discipline.csv` for a bar chart; bars are generally easier to compare than a pie chart.

## 4. Dashboard plan
### Dashboard 1 — Global Olympic Overview
- KPI cards: athlete-medal records, unique athletes (from participation data), number of disciplines, number of NOCs.
- Bar chart: Top 10 NOCs by athlete-medal records.
- Line chart: athlete-medal records by year, colored by Summer/Winter.
- Filters: Games type, year range, discipline, NOC.

### Dashboard 2 — Sports and Medal Analysis
- Top disciplines by athlete-medal records.
- Gold/Silver/Bronze composition by discipline.
- Country/NOC vs discipline heatmap (NOC rows, discipline columns, medal records on Color).
- Filters: year, Games type, NOC.

### Dashboard 3 — Country Performance Over Time
- Line chart for selected NOCs across years.
- Side-by-side medal-record composition.
- Participation trend.
- Filters: Games type and NOC.

### Story — What the data tells us
Create story points in this order:
1. Overall Olympic coverage and dataset caveats.
2. NOCs with the highest athlete-medal records.
3. Disciplines with the highest records.
4. Changes over time and Summer/Winter differences.
5. Data limitations and recommendations for further analysis.

## 5. Visual design
- Use a consistent dark navy / white / gold accent palette.
- Use descriptive chart titles, clear units, readable labels, and a single shared filter row.
- Prefer sorted bars for rankings and lines for time trends.
- Add dashboard filter actions only when they make a chart easier to explore.
- Add a note: “Counts are athlete-medal records; team-event athletes can each appear in the results.”

## 6. Sports investment scenario
For the 2024/2026 context, use `data/recent_games_medal_table_supplement_2024_2026.csv` as a separate medal-table source for selected leading NOCs only. It is not athlete-level data and should not be unioned with the results table. Detailed athlete-event data in the supplied source ends in 2022.

The supplied files do not contain investment/funding amounts. To answer the investment scenario, add a credible dataset with country/NOC, year, and investment amount, cite its source, harmonize country identifiers, and clearly distinguish correlation from causation. Until then, do not build or label a chart as investment efficiency.
