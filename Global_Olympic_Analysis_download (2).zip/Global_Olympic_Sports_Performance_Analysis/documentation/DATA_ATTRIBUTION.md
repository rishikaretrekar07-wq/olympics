# Data attribution

The supplied source repository states that the Olympic athlete biographies and event results were collected from Olympedia.org. Please review the source dataset's LICENSE file and any upstream terms before redistributing the raw data publicly. This project package includes the cleaned source tables for the user's analysis workflow; retain source attribution in any public repository.
